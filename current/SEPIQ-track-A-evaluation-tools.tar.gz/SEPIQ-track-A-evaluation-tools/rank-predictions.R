#!/usr/bin/env Rscript

# Usage: Rscript rank-predictions.R OUTPUT_DIRECTORY scores1.tsv scores2.tsv ... scoresN.tsv
# Calculate CASP-style Z-scores separately for epitope and paratope predictions.

read_scores <- function(file) {
  data <- read.delim(file, colClasses = "character", check.names = FALSE)
  required <- c("prediction_file", "binding_site_type", "pr_auc", "area_weighted_pr_auc", "f1", "balanced_accuracy")
  if (!all(required %in% names(data))) stop("Missing required columns in ", file)
  if (nrow(data) == 0) stop("Empty scores table: ", file)
  if (anyNA(data[required]) || any(data$prediction_file == "")) stop("Missing values in ", file)
  if (!setequal(data$binding_site_type, c("epitope", "paratope")) || nrow(data) != 2) {
    stop("Expected one epitope row and one paratope row in ", file)
  }

  for (metric in c("pr_auc", "area_weighted_pr_auc", "f1", "balanced_accuracy")) {
    data[[metric]] <- suppressWarnings(as.numeric(data[[metric]]))
    if (any(!is.finite(data[[metric]]))) stop("Invalid ", metric, " values in ", file)
  }
  return(data)
}

# First standardize all values, then repeat using only values with initial Z >= 0.
# The final negative Z-scores are replaced with zero.
casp_zscores <- function(values, description) {
  if (length(values) < 2 || sd(values) == 0) {
    warning("Cannot standardize ", description, ": fewer than two distinct values; using zeros", call. = FALSE)
    return(rep(0, length(values)))
  }

  initial_z <- (values - mean(values)) / sd(values)
  selected <- values[initial_z >= 0]

  if (length(selected) < 2 || sd(selected) == 0) {
    warning("Cannot readjust ", description, ": too few distinct above-average values; using initial Z-scores", call. = FALSE)
    return(pmax(0, initial_z))
  }

  adjusted_z <- (values - mean(selected)) / sd(selected)
  return(pmax(0, adjusted_z))
}

rank_predictions <- function(data, binding_site_type) {
  data <- data[data$binding_site_type == binding_site_type, , drop = FALSE]
  if (nrow(data) == 0) stop("No scores for ", binding_site_type)

  if (anyDuplicated(data$prediction_file)) {
    warning("Repeated prediction_file names in ", binding_site_type, " table", call. = FALSE)
  }

  data$z_pr_auc <- casp_zscores(data$pr_auc, paste(binding_site_type, "pr_auc"))
  data$z_area_weighted_pr_auc <- casp_zscores(data$area_weighted_pr_auc, paste(binding_site_type, "area_weighted_pr_auc"))
  data$z_f1 <- casp_zscores(data$f1, paste(binding_site_type, "f1"))
  data$z_balanced_accuracy <- casp_zscores(data$balanced_accuracy, paste(binding_site_type, "balanced_accuracy"))

  data$weighted_z_score <- 0.4 * data$z_pr_auc +
                           0.4 * data$z_area_weighted_pr_auc +
                           0.1 * data$z_f1 +
                           0.1 * data$z_balanced_accuracy

  data <- data[order(
    -data$weighted_z_score,
    -data$pr_auc,
    -data$area_weighted_pr_auc,
    -data$f1,
    -data$balanced_accuracy,
    data$prediction_file
  ), , drop = FALSE]

  data <- data.frame(rank = seq_len(nrow(data)), data, row.names = NULL)
  
  data <- data[c("rank", "prediction_file", "binding_site_type", "weighted_z_score", "z_pr_auc", "z_area_weighted_pr_auc", "z_f1", "z_balanced_accuracy", "pr_auc", "area_weighted_pr_auc", "f1", "balanced_accuracy", "tp", "fp", "tn", "fn")]
  
  return(data)
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) < 2) stop("Usage: Rscript rank-predictions.R OUTPUT_DIRECTORY scores1.tsv scores2.tsv ... scoresN.tsv")

  output_directory <- args[1]
  if (output_directory == "") stop("Output directory must not be empty")
  if (!dir.exists(output_directory)) dir.create(output_directory, recursive = TRUE)
  if (!dir.exists(output_directory)) stop("Cannot create output directory: ", output_directory)

  output_files <- file.path(output_directory, c("epitope-ranking.tsv", "paratope-ranking.tsv"))
  if (any(normalizePath(output_files, mustWork = FALSE) %in% normalizePath(args[-1], mustWork = FALSE))) {
    stop("Output would overwrite an input file")
  }

  scores <- NULL
  for (file in args[-1]) {
    current <- read_scores(file)
    if (is.null(scores)) scores <- current else scores <- rbind(scores, current)
  }

  options(digits = 16)
  for (binding_site_type in c("epitope", "paratope")) {
    ranked <- rank_predictions(scores, binding_site_type)
    output_file <- file.path(output_directory, paste0(binding_site_type, "-ranking.tsv"))
    write.table(ranked, output_file, sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
    message("Wrote ", nrow(ranked), " rows to ", output_file)
  }
}

tryCatch(main(), error = function(error) {
  cat("Error: ", conditionMessage(error), "\n", sep = "", file = stderr())
  quit(status = 1)
})
