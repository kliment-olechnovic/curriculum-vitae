#!/usr/bin/env Rscript

# Usage: Rscript evaluate-prediction.R ALL_RESIDUES INTERFACE_RESIDUES PREDICTIONS ANTIGEN_CHAIN ANTIBODY_CHAIN OUTPUT_DIRECTORY
# Each input table may be either .tsv or .csv; results are written as TSV and PNG.
# PR-AUC uses trapezoidal integration, with the curve starting at recall=0, precision=1.
# Area-weighted PR-AUC uses ordinary precision and area-weighted recall.

read_input <- function(file, required_columns) {
  if (grepl("\\.csv$", file, ignore.case = TRUE)) {
    data <- read.csv(file, colClasses = "character", check.names = FALSE)
  } else if (grepl("\\.tsv$", file, ignore.case = TRUE)) {
    data <- read.delim(file, colClasses = "character", check.names = FALSE)
  } else {
    stop("Expected a .tsv or .csv file: ", file)
  }
  if (!all(required_columns %in% names(data))) stop("Missing columns in ", file)
  data <- data[required_columns]
  for (column in required_columns) {
    data[[column]] <- trimws(data[[column]])
    if (any(is.na(data[[column]]) | data[[column]] == "")) stop("Missing values in ", file, ": ", column)
  }
  return(data)
}

check_residues <- function(data, description) {
  id <- paste(data$chain, data$seqNum, sep = ":")
  if (anyDuplicated(id)) stop("Duplicate chain/residue number in ", description, ": ", id[anyDuplicated(id)])
}

read_number <- function(values, description) {
  numbers <- suppressWarnings(as.numeric(values))
  if (any(!is.finite(numbers))) stop("Invalid numeric values in ", description)
  return(numbers)
}

prepare_data <- function(residue_file, interface_file, prediction_file, antigen_chain, antibody_chain) {
  keys <- c("chain", "seqNum", "resName")
  residues <- read_input(residue_file, keys)
  interfaces <- read_input(interface_file, c(keys, "fact", "weight"))
  predictions <- read_input(prediction_file, c(keys, "prediction"))

  check_residues(residues, "all-residues")
  check_residues(interfaces, "epitope-and-paratope")
  check_residues(predictions, "predictions")

  interfaces$fact <- read_number(interfaces$fact, "interface labels")
  interfaces$weight <- read_number(interfaces$weight, "interface areas")
  predictions$prediction <- read_number(predictions$prediction, "predictions")
  if (any(interfaces$fact != 1 | interfaces$weight <= 0)) stop("Interface rows must have fact=1 and weight>0")
  if (any(predictions$prediction < 0 | predictions$prediction > 1)) stop("Predictions must be between 0 and 1")

  residues <- residues[residues$chain %in% c(antigen_chain, antibody_chain), , drop = FALSE]
  if (!any(residues$chain == antigen_chain)) stop("Antigen chain not found in all-residues: ", antigen_chain)
  if (!any(residues$chain == antibody_chain)) stop("Antibody chain not found in all-residues: ", antibody_chain)

  # Reject a different residue name at a known chain/residue number.
  reference_id <- paste(residues$chain, residues$seqNum, sep = ":")
  for (table in list(interfaces, predictions)) {
    match_index <- match(paste(table$chain, table$seqNum, sep = ":"), reference_id)
    wrong_name <- which(!is.na(match_index) & table$resName != residues$resName[match_index])
    if (length(wrong_name) > 0) stop("Residue name mismatch: ", table$chain[wrong_name[1]], " ", table$seqNum[wrong_name[1]])
  }

  residues$in_scope <- TRUE
  data <- merge(residues, interfaces, by = keys, all = TRUE)
  data <- merge(data, predictions, by = keys, all = TRUE)
  outside <- is.na(data$in_scope)

  if (any(outside & !is.na(data$fact))) stop("Ground-truth interface residue outside all-residues scope")
  ignored <- sum(outside & !is.na(data$prediction))
  if (ignored > 0) warning(ignored, " prediction rows outside evaluation scope were ignored", call. = FALSE)

  for (chain in c(antigen_chain, antibody_chain)) {
    if (any(predictions$chain == chain) && !any(!outside & data$chain == chain & !is.na(data$prediction))) {
      stop("No predictions match the evaluable residues of chain ", chain, "; check numbering")
    }
  }

  data <- data[!outside, , drop = FALSE]
  missing_predictions <- sum(is.na(data$prediction))
  data$fact[is.na(data$fact)] <- 0
  data$weight[is.na(data$weight)] <- 0
  data$prediction[is.na(data$prediction)] <- 0
  if (missing_predictions > 0) message(missing_predictions, " residues without predictions: using prediction=0")
  return(data)
}

# Counts, precision, recall, F1 and balanced accuracy at one threshold.
metrics_at_threshold <- function(data, threshold) {
  predicted_positive <- data$prediction >= threshold
  tp <- sum(predicted_positive & data$fact == 1)
  fp <- sum(predicted_positive & data$fact == 0)
  tn <- sum(!predicted_positive & data$fact == 0)
  fn <- sum(!predicted_positive & data$fact == 1)

  precision <- if (tp + fp > 0) tp / (tp + fp) else 1
  recall <- if (tp + fn > 0) tp / (tp + fn) else NA_real_
  total_area <- sum(data$weight)
  area_recall <- if (total_area > 0) sum(data$weight[predicted_positive]) / total_area else NA_real_
  f1 <- if (2 * tp + fp + fn > 0) 2 * tp / (2 * tp + fp + fn) else 0
  balanced_accuracy <- if (tp + fn > 0 && tn + fp > 0) (tp / (tp + fn) + tn / (tn + fp)) / 2 else NA_real_

  return(data.frame(threshold, tp, fp, tn, fn, precision, recall, area_recall, f1, balanced_accuracy))
}

# Integrate linearly between adjacent precision-recall points.
# (0, 1) represents the threshold above the largest prediction score.
trapezoidal_pr_auc <- function(recall, precision) {
  if (anyNA(recall)) return(NA_real_)
  previous_recall <- 0
  previous_precision <- 1
  area <- 0
  for (i in seq_along(recall)) {
    area <- area + (recall[i] - previous_recall) * (precision[i] + previous_precision) / 2
    previous_recall <- recall[i]
    previous_precision <- precision[i]
  }
  return(area)
}

# Each distinct prediction score defines a point; tied scores are processed together.
evaluate_chain <- function(data, chain, interface_name) {
  data <- data[data$chain == chain, , drop = FALSE]
  thresholds <- sort(unique(data$prediction), decreasing = TRUE)
  curve <- data.frame()
  for (threshold in thresholds) curve <- rbind(curve, metrics_at_threshold(data, threshold))

  ordinary_auc <- trapezoidal_pr_auc(curve$recall, curve$precision)
  weighted_auc <- trapezoidal_pr_auc(curve$area_recall, curve$precision)
  fixed <- metrics_at_threshold(data, 0.5)
  scores <- data.frame(
    binding_site_type = interface_name, chain = chain, n_residues = nrow(data),
    n_positives = sum(data$fact == 1), n_negatives = sum(data$fact == 0),
    pr_auc = ordinary_auc, area_weighted_pr_auc = weighted_auc,
    f1 = fixed$f1, balanced_accuracy = fixed$balanced_accuracy,
    tp = fixed$tp, fp = fixed$fp, tn = fixed$tn, fn = fixed$fn
  )
  return(list(scores = scores, curve = curve, fixed = fixed))
}

# Plot the same straight-line segments used in trapezoidal integration.
plot_pr <- function(curve, recall_column, auc, output_file, title, x_label) {
  png(output_file, width = 2400, height = 1800, res = 300)
  plot(0, 0, type = "n", xlim = c(0, 1), ylim = c(0, 1), xlab = x_label, ylab = "Precision", main = title)
  grid(col = "gray90")

  if (is.na(auc)) {
    text(0.5, 0.5, "Undefined: no positive residues")
  } else {
    recall <- c(0, curve[[recall_column]])
    precision <- c(1, curve$precision)
    lines(recall, precision, col = "steelblue4", lwd = 2)
    legend("topright", legend = sprintf("Trapezoidal PR-AUC = %.4f", auc), bty = "n")
  }
  dev.off()
}

plot_threshold_metrics <- function(evaluation, output_file, title) {
  curve <- evaluation$curve
  png(output_file, width = 2400, height = 1800, res = 300)
  plot(0, 0, type = "n", xlim = c(0, 1), ylim = c(0, 1), xlab = "Prediction threshold", ylab = "Score", main = title)
  grid(col = "gray90")
  abline(v = 0.5, lty = 1, lwd = 1, col = "gray70")

  lines(curve$threshold, curve$f1, col = "steelblue4", lwd = 1)
  points(curve$threshold, curve$f1, col = "steelblue4", pch = 16, cex = 0.55)
  lines(curve$threshold, curve$balanced_accuracy, col = "forestgreen", lwd = 1)
  points(curve$threshold, curve$balanced_accuracy, col = "forestgreen", pch = 16, cex = 0.55)

  points(0.5, evaluation$fixed$f1, col = "steelblue4", pch = 16, cex = 1.4)
  points(0.5, evaluation$fixed$balanced_accuracy, col = "forestgreen", pch = 16, cex = 1.4)
  legend("bottomleft", bty = "n", lty = 1, pch = 16, col = c("steelblue4", "forestgreen"),
         legend = c(sprintf("F1 at 0.5 = %.4f", evaluation$fixed$f1),
                    sprintf("Balanced accuracy at 0.5 = %.4f", evaluation$fixed$balanced_accuracy)))
  dev.off()
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) != 6) stop("Usage: Rscript evaluate-prediction.R ALL_RESIDUES INTERFACE_RESIDUES PREDICTIONS ANTIGEN_CHAIN ANTIBODY_CHAIN OUTPUT_DIRECTORY (inputs: .tsv or .csv)")
  antigen_chain <- args[4]
  antibody_chain <- args[5]
  output_directory <- args[6]
  if (antigen_chain == "" || antibody_chain == "" || antigen_chain == antibody_chain) stop("Antigen and antibody chains must be different and nonempty")
  if (output_directory == "") stop("Output directory must not be empty")
  if (!dir.exists(output_directory)) dir.create(output_directory, recursive = TRUE)
  if (!dir.exists(output_directory)) stop("Cannot create output directory: ", output_directory)

  for (file in c("scores.tsv", "epitope-pr-auc.png", "epitope-area-weighted-pr-auc.png", "epitope-threshold-vs-f1.png", "paratope-pr-auc.png", "paratope-area-weighted-pr-auc.png", "paratope-threshold-vs-f1.png")) {
    output_path <- normalizePath(file.path(output_directory, file), mustWork = FALSE)
    if (output_path %in% normalizePath(args[1:3], mustWork = FALSE)) stop("Output would overwrite an input: ", output_path)
  }

  data <- prepare_data(args[1], args[2], args[3], antigen_chain, antibody_chain)
  epitope <- evaluate_chain(data, antigen_chain, "epitope")
  paratope <- evaluate_chain(data, antibody_chain, "paratope")
  scores <- rbind(epitope$scores, paratope$scores)
  scores <- data.frame(prediction_file = basename(args[3]), scores)
  options(digits = 16)
  write.table(scores, file.path(output_directory, "scores.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")

  for (name in c("epitope", "paratope")) {
    evaluation <- if (name == "epitope") epitope else paratope
    title <- paste0(name, " (chain ", evaluation$scores$chain, ")")
    plot_pr(evaluation$curve, "recall", evaluation$scores$pr_auc, file.path(output_directory, paste0(name, "-pr-auc.png")), paste(title, "precision-recall"), "Recall")
    plot_pr(evaluation$curve, "area_recall", evaluation$scores$area_weighted_pr_auc, file.path(output_directory, paste0(name, "-area-weighted-pr-auc.png")), paste(title, "area-weighted precision-recall"), "Area-weighted recall")
    plot_threshold_metrics(evaluation, file.path(output_directory, paste0(name, "-threshold-vs-f1.png")), paste(title, "F1 and balanced accuracy vs threshold"))
  }
  message("Finished, see output files in ", output_directory)
}

tryCatch(main(), error = function(error) {
  cat("Error: ", conditionMessage(error), "\n", sep = "", file = stderr())
  quit(status = 1)
})
