#!/bin/bash

cd "$(dirname $0)"

echo "Deleting './example/ground_truth_processed'"

rm -rf './example/ground_truth_processed'

echo "Regenerating './example/ground_truth_processed'"

bash ./get-epitope-and-paratope-data-from-ground-truth-structure.sh \
  ./example/ground_truth_raw/8GZ5-assembly1.cif \
  A \
  B \
  ./example/ground_truth_processed

echo "Deleting './example/output_evaluations'"

rm -rf '../example/output_evaluations'

find ./example/input_predictions -type f | sort \
| while read -r PREDICTION_FILE
do
	PREDICTION_NAME="$(basename ${PREDICTION_FILE} .csv)"
	PREDICTION_NAME="$(basename ${PREDICTION_NAME} .tsv)"
	
	echo "Regenerating './example/output_evaluations/${PREDICTION_NAME}'"

	Rscript ./evaluate-prediction.R \
	  ./example/ground_truth_processed/all-residues.tsv \
	  ./example/ground_truth_processed/epitope-and-paratope.tsv \
	  "$PREDICTION_FILE" \
	  A \
	  B \
	  ./example/output_evaluations/${PREDICTION_NAME}
done
