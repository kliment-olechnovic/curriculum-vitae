#!/bin/bash

if [ "$#" -ne 3 ]
then
cat << 'EOF' >&2
This script needs exactly three parameters: "input_structure_file" "input_sequences_file" "output_directory_path"

Usage example:
  
  renumber-structure-residues-by-sequences.sh "input_file.cif" "sequences.fasta" "./structure_renumbered"

EOF
	exit 1
fi

ZEROARG=$0

if [[ $ZEROARG == *"/"* ]]
then
	cd "$(dirname ${ZEROARG})"
	export PATH="$(pwd):${PATH}"
	cd - &> /dev/null
fi

command -v cadscore-lt &> /dev/null || { echo >&2 "Error: 'cadscore-lt' executable is not installed and not available in the directory of this script."; exit 1; }

STRUCTFILE="$1"
SEQFILE="$2"
OUTPUT_DIRECTORY_PATH="$3"

if [ ! -s "$STRUCTFILE" ]
then
	echo >&2 "Error: invalid input structure file '$STRUCTFILE'."
	exit 1
fi

if [ ! -s "$SEQFILE" ]
then
	echo >&2 "Error: invalid input sequences file '$SEQFILE'."
	exit 1
fi

if [ -z "$OUTPUT_DIRECTORY_PATH" ]
then
	echo >&2 "Error: provided output directory path is empty."
	exit 1
fi

readonly TMPLDIR=$(mktemp -d)
trap "rm -r $TMPLDIR" EXIT

cadscore-lt \
  -m "$STRUCTFILE" \
  --reference-sequences-file "$SEQFILE" \
  --reference-stoichiometry 1 1 \
  --output-dir "${TMPLDIR}/outdir" \
  --save-processed-inputs-pdb \
  --save-processed-inputs-mmcif \
  --save-sequence-alignments \
  --quit-before-scoring

RENUMBEREDFILE_PDB="${TMPLDIR}/outdir/processed_inputs_as_pdb/i0.pdb"
RENUMBEREDFILE_MMCIF="${TMPLDIR}/outdir/processed_inputs_as_mmcif/i0.cif"
SEQALIGNMENTS_FILE="${TMPLDIR}/outdir/reference_based_sequence_alignments.txt"

if [ ! -s "$RENUMBEREDFILE_PDB" ] || [ ! -s "$RENUMBEREDFILE_MMCIF" ] || [ ! -s "$SEQALIGNMENTS_FILE" ]
then
	echo >&2 "Failed to renumber structure"
	exit 1
fi

mkdir -p "$OUTPUT_DIRECTORY_PATH"

if [ ! -d "$OUTPUT_DIRECTORY_PATH" ]
then
	echo >&2 "Error: cannot create output directory '$OUTPUT_DIRECTORY_PATH'."
	exit 1
fi

mv "$RENUMBEREDFILE_PDB" "${OUTPUT_DIRECTORY_PATH}/renumbered.pdb"
mv "$RENUMBEREDFILE_MMCIF" "${OUTPUT_DIRECTORY_PATH}/renumbered.cif"
mv "$SEQALIGNMENTS_FILE" "${OUTPUT_DIRECTORY_PATH}/reference_based_sequence_alignments.txt"

exit 0

