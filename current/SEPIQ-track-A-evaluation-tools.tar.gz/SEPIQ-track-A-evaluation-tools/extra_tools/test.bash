#!/bin/bash

cd "$(dirname $0)"

echo "Deleting './example/ground_truth_renumbered'"

rm -rf './example/ground_truth_renumbered'

echo "Regenerating './example/ground_truth_renumbered'"

bash ./renumber-structure-residues-by-sequences.sh \
  ./example/ground_truth_raw/8GZ5-assembly1.cif \
  ./example/ground_truth_raw/8GZ5.fasta \
  ./example/ground_truth_renumbered

