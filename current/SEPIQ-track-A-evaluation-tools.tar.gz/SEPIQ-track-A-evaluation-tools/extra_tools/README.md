# Extra tools

## Renumbering a heterodimer structure according to the chain A and B sequences

The script `renumber-structure-residues-by-sequences.sh` uses `cadscore-lt` app to renumber input structure according to input sequences.

CAD-score-LT version 0.9.196 is included in the script directory (`cadscore-lt` binary).

The script needs exactly four parameters: "input_structure_file" "input_sequences_file" "output_directory_path"

Usage example:

```bash
bash ./renumber-structure-residues-by-sequences.sh \
  ./example/ground_truth_raw/8GZ5-assembly1.cif \
  ./example/ground_truth_raw/8GZ5.fasta \
  ./example/ground_truth_renumbered
```

For examples of input and output files, see `example` directory

### Test

The `test.bash` script runs `renumber-structure-residues-by-sequences.sh` to regenerate `./example/ground_truth_renumbered`.

