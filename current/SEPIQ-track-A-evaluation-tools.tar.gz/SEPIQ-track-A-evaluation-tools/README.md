# SEPIQ Track A: residue-level prediction evaluation

These scripts prepare structural ground truth and evaluate residue-level epitope and paratope predictions for **SEPIQ Track A**. The workflow has two stages:

1. Use **Voronota-LT** to identify antigen–VHH interface residues and their contact areas in an experimental complex structure.
2. Use **base R** to compare one prediction table with that ground truth, calculate performance scores, and generate plots.

Epitope (antigen) and paratope (VHH) predictions are evaluated **separately**. Each invocation evaluates **one antigen–antibody complex and one prediction file**.

The approach follows the [SEPIQ Track A evaluation guideline](https://sepiq.uk/guideline), with the implementation choices and current limits noted below.

## Requirements

- Bash and standard command-line utilities (`awk`, `tail`, `sed`, `wc`).
- `voronota-lt`, available on `PATH` or in the same directory as the ground-truth preparation script. Voronota-LT version 1.1.479 is included in this repository.
- R with `Rscript` and PNG graphics support. No additional R packages are required.

The R evaluation script is cross-platform. The ground-truth preparation script requires a Bash environment (for example, Linux, macOS, or Bash/WSL on Windows).

## 1. Prepare structural ground truth

Run:

```bash
bash ./get-epitope-and-paratope-data-from-ground-truth-structure.sh \
  ./example/ground_truth_raw/8GZ5-assembly1.cif \
  A \
  B \
  ./example/ground_truth_processed
```

Arguments, in order:

1. Experimental antigen–VHH complex structure (PDB or mmCIF file supported by Voronota-LT).
2. Antigen chain identifier (here `A`).
3. VHH/antibody chain identifier (here `B`).
4. Output directory (created if necessary).

The output directory contains:

| File | Contents |
| --- | --- |
| `all-residues.tsv` | All structurally represented residues from the selected antigen and VHH chains: `chain`, `seqNum`, `resName`. |
| `binding-sites.tsv` | Original Voronota-LT residue-level inter-chain contact table. |
| `epitope-and-paratope.tsv` | Positive interface residues only: `chain`, `seqNum`, `resName`, `fact`, `weight`. |

In `epitope-and-paratope.tsv`, `fact` is `1` and `weight` is the residue-level inter-chain contact area calculated by Voronota-LT. Non-interface residues do not appear in this file. The evaluator identifies them using `all-residues.tsv` and assigns `fact = 0` and `weight = 0`.

The preparation script excludes heteroatoms and restricts interface contacts to the specified antigen and VHH chains. Existing output tables in the destination directory are overwritten.

## 2. Evaluate a prediction

Run:

```bash
Rscript ./evaluate-prediction.R \
  ./example/ground_truth_processed/all-residues.tsv \
  ./example/ground_truth_processed/epitope-and-paratope.tsv \
  ./example/input_predictions/prediction1.tsv \
  A \
  B \
  ./example/output_evaluations/prediction1
```

Arguments, in order:

1. `all-residues.tsv` from step 1.
2. `epitope-and-paratope.tsv` from step 1.
3. Participant prediction file, in either TSV or CSV format.
4. Antigen chain identifier.
5. VHH/antibody chain identifier.
6. Output directory (created if necessary).

All three input tables may independently use `.tsv` or `.csv`; the file extension determines how each is read. The output score table is always TSV.

The prediction file must contain the columns:

```text
chain  seqNum  resName  prediction
A      334     ASN      0.54
A      335     LEU      0.00
B      1       GLN      0.83
```

`prediction` must be a finite number between 0 and 1. Residues may be omitted: their prediction is then taken as **0**, consistent with the SEPIQ guideline.

### Evaluation output

The output directory contains:

```text
scores.tsv
epitope-pr-auc.png
epitope-area-weighted-pr-auc.png
epitope-threshold-vs-f1.png
paratope-pr-auc.png
paratope-area-weighted-pr-auc.png
paratope-threshold-vs-f1.png
```

`scores.tsv` has one row for the **epitope** and one for the **paratope**. Its columns are:

| Column | Meaning |
| --- | --- |
| `prediction_file` | Basename of the prediction file (useful when combining results from multiple submissions). |
| `binding_site_type` | `epitope` or `paratope`. |
| `chain` | Chain identifier used for that evaluation. |
| `n_residues`, `n_positives`, `n_negatives` | Numbers of evaluable residues and interface/non-interface residues. |
| `pr_auc` | Ordinary average precision (AP), using stepwise PR-AUC integration. |
| `area_weighted_pr_auc` | Area-weighted AP, using area-weighted recall and ordinary precision. |
| `f1`, `balanced_accuracy` | Binary classification scores at threshold **0.5**. |
| `tp`, `fp`, `tn`, `fn` | Confusion-matrix counts at threshold **0.5**. |

Each binding-site type also gets three **2400 × 1800 px, 300-DPI** plots: the ordinary precision–recall curve, the area-weighted precision–recall curve, and F1 plus balanced accuracy versus prediction threshold. The PR curves show the horizontal steps used in AP integration. The threshold plots highlight the scores at threshold 0.5.

### Score definitions

At prediction threshold `t`, a residue is classified as positive when `prediction >= t`. Precision is `TP / (TP + FP)`, and ordinary recall is `TP / (TP + FN)`.

For **area-weighted recall**, each positive residue has a weight equal to its Voronota-LT interface contact area:

```text
area-weighted recall = sum(contact areas of correctly predicted interface residues)
                       / sum(contact areas of all interface residues)
```

Precision is **not** area-weighted. Both PR curves are calculated over the distinct prediction thresholds, processing equal prediction scores together. **PR-AUC is calculated as average precision (AP)**, not by trapezoidal interpolation:

```text
AP = sum((recall[i] - recall[i - 1]) * precision[i])
```

Here `recall[0] = 0`. For area-weighted AP, `recall` means area-weighted recall; precision remains unweighted. The PR plots use horizontal steps whose areas equal the reported AP scores. The conventional plot starting point `(recall = 0, precision = 1)` adds no area. The output column names `pr_auc` and `area_weighted_pr_auc` are retained for compatibility with existing score tables, but their values now use the AP convention and **will differ from results produced by the previous trapezoidal implementation**.

At threshold 0.5, `f1 = 2TP / (2TP + FP + FN)` and `balanced_accuracy = (sensitivity + specificity) / 2`. These are supplementary diagnostics.

### Residue matching and evaluation scope

The evaluator matches records by the exact combination of `chain`, `seqNum`, and `resName`. It checks for duplicate residue identifiers, invalid numerical values, and mismatched residue names.

- `all-residues.tsv` defines the **evaluable residues**. Residues absent from the experimental structure are not automatically considered negatives.
- Positive ground-truth residues outside that scope produce an error.
- Predictions outside that scope produce a warning and are ignored.
- Missing predictions for evaluable residues are replaced with 0.
- Missing positive-interface records for evaluable residues are treated as non-interface residues with weight 0.

**Important:** Neither script automatically reconciles PDB/mmCIF residue numbering with the numbering used in the published SEPIQ prediction templates. Chain identifiers, residue numbers, and amino-acid names must already agree. Check and correct this mapping before evaluation, especially for incomplete structures, expression tags, insertion codes, or different chain naming.

## 3. Rank predictions for one complex

After evaluating several prediction files against the **same antigen–VHH complex**, combine their `scores.tsv` files and rank the predictions:

```bash
Rscript ./rank-predictions.R \
  ./example/output_ranks \
  ./example/output_evaluations/*/scores.tsv
```

The first argument is the output directory (created if needed). All remaining arguments are score tables produced by `evaluate-prediction.R`; each must contain one `epitope` and one `paratope` row. There is no limit on the number of score files.

The script concatenates all score tables and calculates **independent rankings for epitope and paratope**. It writes two files:

- `epitope-ranking.tsv`
- `paratope-ranking.tsv`

Each output preserves all original score-table columns, including the four raw metrics (`pr_auc`, `area_weighted_pr_auc`, `f1`, and `balanced_accuracy`), and adds their four adjusted Z-scores (`z_pr_auc`, `z_area_weighted_pr_auc`, `z_f1`, and `z_balanced_accuracy`), `weighted_z_score`, and `rank`. Files are sorted by descending `weighted_z_score`. Equal scores receive the same rank and are ordered alphabetically by prediction filename.

For each binding-site type and each metric separately, the script applies this **CASP-style Z-score adjustment**:

1. Calculate initial Z-scores from the mean and sample standard deviation of all predictions.
2. Recalculate the mean and sample standard deviation using only predictions with an initial Z-score greater than or equal to zero.
3. Use those recalculated statistics to obtain adjusted Z-scores for every prediction, replacing negative adjusted Z-scores with zero.

The final ranking score is:

```text
weighted_z_score = 0.4 * z_pr_auc
                 + 0.4 * z_area_weighted_pr_auc
                 + 0.1 * z_f1
                 + 0.1 * z_balanced_accuracy
```

If every prediction has the same value for a metric, that metric contributes zero for all predictions. If fewer than two distinct predictions remain in the above-average group, recalibration is undefined; the script warns and uses the initial Z-scores clipped to zero instead.

**Important:** This script compares predictions **for the same complex**. It does not implement final across-all-complexes macro-averaging and ranking. In particular, score tables for different complexes must not be combined in a single call.

## Scope of this release

These scripts produce per-complex prediction scores, plots, and CASP-style within-complex rankings. They do not perform across-complex aggregation or significance testing.

## Tests

The `test.bash` script:
* runs `get-epitope-and-paratope-data-from-ground-truth-structure.sh` to regenerate `./example/ground_truth_processed`;
* runs `evaluate-prediction.R` to regenerate `./example/output_evaluations`.
* runs `rank-prediction.R` to regenerate `./example/output_ranks`.

