#!/bin/bash

if [ "$#" -ne 4 ]
then
cat << 'EOF' >&2
This script needs exactly four parameters: "input_file" "antigen_chain_name" "antibody_chain_name" "output_directory_path"

Usage example:
  
  get-epitope-and-paratope-data-from-ground-truth-structure "input_file.cif" "A" "B" "./ground_truth/tables"

EOF
	exit 1
fi

ZEROARG=$0

if [[ $ZEROARG == *"/"* ]]
then
	cd "$(dirname ${ZEROARG})"
	export PATH="$(pwd):${PATH}"
	cd - &> /dev/null
fi

command -v voronota-lt &> /dev/null || { echo >&2 "Error: 'voronota-lt' executable is not installed and not available in the directory of this script."; exit 1; }

INPUT_GROUND_TRUTH_STRUCTURE="$1"
INPUT_ANTIGEN_CHAIN_NAME="$2"
INPUT_ANTIBODY_CHAIN_NAME="$3"
OUTPUT_DIRECTORY_PATH="$4"

if [ ! -s "$INPUT_GROUND_TRUTH_STRUCTURE" ]
then
	echo >&2 "Error: invalid input file '$INPUT_GROUND_TRUTH_STRUCTURE'."
	exit 1
fi

if [ -z "$INPUT_ANTIGEN_CHAIN_NAME" ]
then
	echo >&2 "Error: provided antigen chain name is empty."
	exit 1
fi

if [ -z "$INPUT_ANTIBODY_CHAIN_NAME" ]
then
	echo >&2 "Error: provided antibody chain name is empty."
	exit 1
fi

if [ -z "$OUTPUT_DIRECTORY_PATH" ]
then
	echo >&2 "Error: provided output directory path is empty."
	exit 1
fi

mkdir -p "$OUTPUT_DIRECTORY_PATH"

if [ ! -d "$OUTPUT_DIRECTORY_PATH" ]
then
	echo >&2 "Error: cannot create output directory '$OUTPUT_DIRECTORY_PATH'."
	exit 1
fi

OUTPUT_ALL_RESIDUES_TABLE_FILE="${OUTPUT_DIRECTORY_PATH}/all-residues.tsv"
OUTPUT_VORONOTA_LT_LOG_FILE="${OUTPUT_DIRECTORY_PATH}/log-of-voronota-lt.txt"
OUTPUT_BINDING_SITES_TABLE_FILE="${OUTPUT_DIRECTORY_PATH}/binding-sites.tsv"
OUTPUT_EPITOPE_AND_PARATOPE_TABLE_FILE="${OUTPUT_DIRECTORY_PATH}/epitope-and-paratope.tsv"

rm -f "$OUTPUT_ALL_RESIDUES_TABLE_FILE"
rm -f "$OUTPUT_BINDING_SITES_TABLE_FILE"
rm -f "$OUTPUT_EPITOPE_AND_PARATOPE_TABLE_FILE"

rm -f "$OUTPUT_VORONOTA_LT_LOG_FILE"

voronota-lt \
  --input "$INPUT_GROUND_TRUTH_STRUCTURE" \
  --pdb-or-mmcif-exclude-heteroatoms \
  --restrict-input-atoms "[-chain ${INPUT_ANTIGEN_CHAIN_NAME},${INPUT_ANTIBODY_CHAIN_NAME}]" \
  --print-cells-residue-level \
2> "$OUTPUT_VORONOTA_LT_LOG_FILE" \
| awk '{if(NR==1){print "chain\tseqNum\tresName"}else{print $2 "\t" $3 "\t" $4}}' \
> "$OUTPUT_ALL_RESIDUES_TABLE_FILE"

if [ "$(wc -l < "$OUTPUT_ALL_RESIDUES_TABLE_FILE")" -le 1 ]
then
	cat >&2 "$OUTPUT_VORONOTA_LT_LOG_FILE"
	echo >&2 "Error: failed to collect all residue identifiers and write them to output file '$OUTPUT_ALL_RESIDUES_TABLE_FILE'."
	exit 1
fi

rm -f "$OUTPUT_VORONOTA_LT_LOG_FILE"

voronota-lt \
  --input "$INPUT_GROUND_TRUTH_STRUCTURE" \
  --pdb-or-mmcif-exclude-heteroatoms \
  --restrict-contacts "[-a1 [-chain ${INPUT_ANTIGEN_CHAIN_NAME}] -a2 [-chain ${INPUT_ANTIBODY_CHAIN_NAME}] -inter-chain]" \
  --write-sites-residue-level-to-file "$OUTPUT_BINDING_SITES_TABLE_FILE" \
&> "$OUTPUT_VORONOTA_LT_LOG_FILE"

if [ ! -s "$OUTPUT_BINDING_SITES_TABLE_FILE" ]
then
	cat >&2 "$OUTPUT_VORONOTA_LT_LOG_FILE"
	echo >&2 "Error: failed to compute binding sites and write them to output file '$OUTPUT_BINDING_SITES_TABLE_FILE'."
	exit 1
fi

rm -f "$OUTPUT_VORONOTA_LT_LOG_FILE"

{
echo "chain seqNum resName fact weight" | sed 's/\s\+/\t/g'
cat "$OUTPUT_BINDING_SITES_TABLE_FILE" | tail -n +2 | awk '{print $2 "\t" $3 "\t" $4 "\t1\t" $5}'
} \
> "$OUTPUT_EPITOPE_AND_PARATOPE_TABLE_FILE"

if [ ! -s "$OUTPUT_EPITOPE_AND_PARATOPE_TABLE_FILE" ]
then
	echo >&2 "Error: failed to describe epitope and paratope and write to output file '$OUTPUT_EPITOPE_AND_PARATOPE_TABLE_FILE'."
	exit 1
fi

